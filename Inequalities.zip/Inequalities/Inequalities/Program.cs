﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

// https://www.dotnetperls.com/streamreader

namespace Inequalities
{
    class Program
    {
        private const string InputFilePath = @"..\..\..\inequalities.in";
        private const string OutputFilePath = @"..\..\..\inequalities.out";

        static void Main()
        {
            using (StreamReader reader = new StreamReader(InputFilePath))
            {
                int minLoopValue = int.MaxValue;
                int maxLoopValue = int.MinValue;

                var expressions = new List<Tuple<string, int>> ();

                while (!reader.EndOfStream)
                {
                    var lineTokens = reader.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    int rightExpressionNum = int.Parse(lineTokens[2]);
                    string oper = lineTokens[1];

                    expressions.Add(new Tuple<string, int>(oper, rightExpressionNum));

                    if (rightExpressionNum < minLoopValue)
                    {
                        minLoopValue = rightExpressionNum;
                    }

                    if (rightExpressionNum > maxLoopValue)
                    {
                        maxLoopValue = rightExpressionNum;
                    }
                }

                var trueExpressions = new Dictionary<int, List<Tuple<int, string, int>>>();
                int maxKey = minLoopValue;
                int maxCount = 0;
                for (int i = minLoopValue; i <= maxLoopValue; i++)
                {
                    foreach (var expr in expressions)
                    {
                        if (ExpressionIsTrue(i, expr.Item1, expr.Item2))
                        {
                            if (trueExpressions.ContainsKey(i) == false)
                            {
                                trueExpressions.Add(i, new List<Tuple<int, string, int>>());
                            }
                            
                            trueExpressions[i].Add(new Tuple<int, string, int>(i, expr.Item1, expr.Item2));
                        }
                    }

                    if (trueExpressions[i].Count > maxCount)
                    {
                        maxKey = i;
                        maxCount = trueExpressions[i].Count;
                    }
                }

                string output = trueExpressions[maxKey].Count.ToString();
                foreach (var exp in trueExpressions[maxKey])
                {
                    string outputLine = $"{exp.Item1} {exp.Item2} {exp.Item3}";
                    output += Environment.NewLine + outputLine;
                }

                Console.WriteLine(output);
            }
        }

        private static bool ExpressionIsTrue(int leftNum, string oper, int rightNum)
        {
            switch (oper)
            {
                case ">":
                    return leftNum > rightNum;
                case "<":
                    return leftNum < rightNum;
                case ">=":
                    return leftNum >= rightNum;
                case "<=":
                    return leftNum <= rightNum;
                case "=":
                    return leftNum == rightNum;
                default:
                    return false;
            }
        }
    }
}
